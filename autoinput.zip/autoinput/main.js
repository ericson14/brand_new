(function () {

  let userAccount = 'SZAntiy'
  let userPassword = 'antiylabsnode)9*'

  let isLogin = location.hash === '#/login'



  if (!isLogin) {
    return
  }
  else {

    setTimeout(() => {
      if (isInit()) {
        setValue()


      }
    }, 1000)

    setTimeout(() => {
      console.log('xxxxx', $('#userAccount')[0].value, $('button[type="submit"]'))
    }, 2000)
  }

  let isInit = () => document.getElementById('userAccount')

  // let changeInitValue = () => {
  //   let account = 
  // }


  let setValue = () => {
    console.log('asdasgg', $('button[type="submit"]'),)
    $('#userAccount')[0].value = userAccount
    // $('#userAccount').change()
    let evt = document.createEvent('HTMLEvents')
    evt.initEvent('change', true, true)
    $('#userAccount')[0].dispatchEvent(evt)

    $('#userPassword')[0].value = userPassword
    $('#userPassword')[0].dispatchEvent(evt)

  }

  // window.addEventListener('enter', )

})()