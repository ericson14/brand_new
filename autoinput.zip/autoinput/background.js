(function () {
  let inituserAccount = 'adminantiy'
  let inituserPassword = 'antiylabsnode)9*'
  let userAccountId = 'userAccount'
  let userPasswordId = 'userPassword'
  let preStorage = '__prearg__'
  let storage = '__list__'




  let origin = location.origin

  let isLogin = location.hash === '#/login'

  let setCache = (key, arg) => localStorage.setItem(key, JSON.stringify(arg))

  let getCache = (key) => JSON.parse(localStorage.getItem(key))


  let accountDom = null
  let passwordDom = null
  //修改获取用户名、密码输入框方式
  let getDom = () => {
    let passwordIndex = -1
    let arr = document.getElementsByTagName('input')
    for (let i = 0; i < arr.length; i++) {
      if (arr[i]?.type === 'password') {
        passwordIndex = i
        passwordDom = arr[i]
        break
      }
    }
    accountDom = arr[passwordIndex - 1]
  }


  //单击登录或者登录页按下enter按钮，存储当前数据
  let savePreArg = () => {
    let preObj = {
      [userAccountId]: accountDom.value,
      [userPasswordId]: passwordDom.value,
      origin: location.origin
    }
    setCache(preStorage, preObj)
    return preObj
  }


  //仅在登录页面做轮询，若当前页面不为登录页时且origin一至，则将preArg参数正式加入密码列表中
  let saveList = (arg = {}) => {
    let obj = Object.keys(arg).length ? arg : getCache(preStorage)
    let arr = getList()
    if (!isRepeat(obj, arr)) {
      setCache([...arr, obj])
    }

  }





  let isRepeat = (obj, arr) => {
    return arr.map(i => getObjKey(i)).includes(getObjKey(obj))
  }

  let getObjKey = (obj) => Object.values(obj).join('')

  let getList = () => {
    return getCache(storage) || []
  }


  let setValue = (obj = {}) => {
    let userAccount = obj['userAccount'] ? obj['userAccount'] : inituserAccount
    let userPassword = obj['userPassword'] ? obj['userPassword'] : inituserPassword

    $('#userAccount')[0].value = userAccount
    let evt = document.createEvent('HTMLEvents')
    evt.initEvent('change', true, true)
    $('#userAccount')[0].dispatchEvent(evt)
    $('#userPassword')[0].value = userPassword
    $('#userPassword')[0].dispatchEvent(evt)
  }

  let clickCheck = (e) => {
    let isSubmit = e?.path[0].type === 'submit'
    if (isSubmit) {
      if (!accountDom || passwordDom) {
        getDom()
        savePreArg()
      }
      else {
        savePreArg()
      }
    }
  }

  let pressEnterCheck = (e) => {

  }

  //循环
  let loop = () => {
    if (isLogin()) {
      window.addEventListener('click', clickCheck)
      window.addEventListener('keydown', pressEnterCheck)
    }
    else {
      window.removeEventListener('click', clickCheck)
      window.removeEventListener('keydown', pressEnterCheck)
      return
    }
  }


  let timer = null
  timer = setInterval(loop, 200)

})()